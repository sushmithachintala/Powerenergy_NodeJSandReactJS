const dbConfig = {
  HOST: '75.126.93.131',
  USER: 'STHGravityTelemedicine',
  PASSWORD: 'KJHGFrtyuh@#456tgF',
  DB: 'STHGravityTelemedicine',
  dialect: "mssql",
  port:7008,
  pool: {
    max: 15,
    min: 5,
    acquire: 30000,
    idle: 10000,
  },
};

module.exports = dbConfig